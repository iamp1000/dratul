const EmergencyBlockModal = ({ onClose }) => {
  const [date, setDate] = React.useState('');
  const [location, setLocation] = React.useState('clinic');
  const [reason, setReason] = React.useState('');
  const [isSubmitting, setIsSubmitting] = React.useState(false);

  const today = new Date().toISOString().split('T')[0];

  const handleSubmit = async () => {
    if (!date || !reason) {
      toast('Please fill date and reason');
      return;
    }
    setIsSubmitting(true);
    try {
      const payload = {
        location_id: location === 'clinic' ? 1 : 2,
        date,
        reason,
      };
      await window.api('/api/v1/appointments/emergency-block', {
        method: 'POST',
        body: JSON.stringify(payload),
      });
      toast('Emergency block applied');
      onClose();
    } catch (err) {
      toast(err.message || 'Failed to block');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="space-y-4">
      <div className="grid grid-cols-1 gap-4">
        <div>
          <label className="block text-sm font-medium text-medical-gray mb-2">Select Date</label>
          <input type="date" min={today} value={date} onChange={(e) => setDate(e.target.value)} className="custom-datetime" />
        </div>
        <div>
          <label className="block text-sm font-medium text-medical-gray mb-2">Location</label>
          <select value={location} onChange={(e) => setLocation(e.target.value)} className="custom-select">
            <option value="clinic">Main Clinic</option>
            <option value="hospital">Hospital</option>
          </select>
        </div>
        <div>
          <label className="block text-sm font-medium text-medical-gray mb-2">Reason for Emergency</label>
          <input type="text" value={reason} onChange={(e) => setReason(e.target.value)} className="form-input-themed" placeholder="e.g., Unforeseen personal matter" />
        </div>
        <div className="flex justify-end space-x-3">
          <button onClick={onClose} className="px-4 py-2 bg-gray-200 text-gray-700 rounded-lg hover:bg-gray-300">Cancel</button>
          <button onClick={handleSubmit} className="bg-red-600 hover:bg-red-700 px-4 py-2 text-white rounded-lg relative z-10" disabled={isSubmitting}>
            {isSubmitting ? 'Saving...' : 'Confirm Emergency Block'}
          </button>
        </div>
      </div>
    </div>
  );
};


